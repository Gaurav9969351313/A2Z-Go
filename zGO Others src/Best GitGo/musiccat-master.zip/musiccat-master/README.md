1. /artistes
   GET
   POST

2. /artistes/{artiste\_id}
   PUT/PATCH
   DELETE

3. /artistes/{artiste\_id}/albums
   GET
   POST

4. /artistes/{artiste\_id}/albums/{album\_id}
   PUT/PATCH
   DELETE

5. /albums/{album\_id}/songs
   GET
   POST

6. /albums/{album\_id}/songs/{song\_id}
   PUT/PATCH
   DELETE

7. /artistes/{artiste\_id}/members
   GET

8. /artistes/{artiste\_id}/acts
   GET
   POST

9. /artistes/{artiste\_id}/acts/{act\_id}
   PUT/PATCH
   DELETE

10. /albums?start\_year=....&end\_year=...
    GET

11. /artistes/{artiste\_id}/albums?start\_year=....&end\_year=...
    GET

