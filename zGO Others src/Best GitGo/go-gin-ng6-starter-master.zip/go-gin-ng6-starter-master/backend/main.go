package main

import (
    "github.com/app8izer/go-gin-ng6-starter/backend/server"
)

func main() {
    server.StartServer()
}
