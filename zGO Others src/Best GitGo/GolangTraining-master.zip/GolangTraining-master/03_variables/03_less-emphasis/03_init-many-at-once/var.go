package main

import "fmt"

func main() {

	var message = "Hello World!"
	var a, b, c int = 1, 2, 3

	fmt.Println(message, a, b, c)
}
