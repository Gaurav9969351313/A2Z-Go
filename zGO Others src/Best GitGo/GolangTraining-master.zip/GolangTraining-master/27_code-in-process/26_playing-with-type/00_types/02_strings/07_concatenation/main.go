package main

import "fmt"

func main() {
	fname := "James"
	lname := "Bond"
	fmt.Println(fname + " " + lname)
}
