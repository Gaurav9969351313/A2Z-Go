package main

import (
	"fmt"
	"strconv"
)

func main() {
	i, _ := strconv.Atoi("32")
	fmt.Println(i + 10)
}
