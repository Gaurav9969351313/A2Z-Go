package vis

// MyName is exported because it starts with a capital letter
var MyName = "Todd"
var yourName = "Future Rock Star Programmer"
