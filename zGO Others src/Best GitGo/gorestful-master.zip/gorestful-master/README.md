[![codecov](https://codecov.io/gh/narenaryan/gorestful/branch/master/graph/badge.svg)](https://codecov.io/gh/narenaryan/gorestful)

# gorestful
A supplementary code for my book Building RESTful web services with Go
