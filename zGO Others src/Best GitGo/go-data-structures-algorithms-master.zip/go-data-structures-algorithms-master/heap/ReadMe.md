### Go语言数据结构和算法-Heap(堆)

```
Add(val)          // 在堆中添加一个新元素
Delete(val)       // 在堆中删除一个元素
Contains(val)     // 在堆中是否包含这个元素
String()          // 遍历堆中的元素
```
