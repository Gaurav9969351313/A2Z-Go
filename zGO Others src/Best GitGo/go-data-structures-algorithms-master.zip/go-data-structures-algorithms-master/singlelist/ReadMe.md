### 单向链表

```
Append(item)        //在链表尾部追加新节点
InsertAt(i,item)    //在索引i处添加新节点
RemoveAt(i)         //删除索引i处的节点
IndexOf(item)       //获取元素的索引
IsEmpty()           //链表是否为空
Size()              //链表的大小
String()            //遍历链表              
GetAt(i)            //获取索引i处的节点
Contains(item)      //是否包含这个元素
Remove(ite)         //删除元素
```