package hello

// Hello is hello world
func Hello() string {
	return "Hello linux"
}
