// +build linux

package hello2

// Hello is hello world
func Hello() string {
	return "Hello linux 2"
}
