// +build darwin

package hello2

// Hello is hello world
func Hello() string {
	return "Hello darwin 2"
}
