// +build go1.8

package hello3

// Hello is hello world
func Hello() string {
	return "build on go1.8"
}
