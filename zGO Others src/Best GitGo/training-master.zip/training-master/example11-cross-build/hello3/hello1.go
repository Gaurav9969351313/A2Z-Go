// +build !go1.8

package hello3

// Hello is hello world
func Hello() string {
	return "build on berfore go1.8 version"
}
