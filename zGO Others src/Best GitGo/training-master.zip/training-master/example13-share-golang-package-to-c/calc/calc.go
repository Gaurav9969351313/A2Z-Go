package calc

// Sum provide x + y
func Sum(x, y int) int {
	return x + y
}
