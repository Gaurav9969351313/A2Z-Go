package main

import "calc"
import "fmt"

func main() {
	fmt.Println("Cashier Application")
	fmt.Printf("Result: %d\n", calc.Sum(5, 10))
}
