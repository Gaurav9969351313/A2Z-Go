# Golang 整合 Docker Image

本範例會介紹如何用 Docker 整合 Golang 執行檔
