
export const environment = {
  production: false,
  api: 'https://51cxzthvma.execute-api.us-east-1.amazonaws.com/staging/movies',
  userPoolId: 'us-east-1_qTCypPvBf',
  clientId: '6ndbtp2jso02odhjo2i1i103n0'
};
