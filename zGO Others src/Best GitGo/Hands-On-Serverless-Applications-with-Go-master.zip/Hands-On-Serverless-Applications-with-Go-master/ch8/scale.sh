#!/bin/bash

hey -n 1000 -c 500 https://API_ID.execute-api.us-east-1.amazonaws.com/staging/movies