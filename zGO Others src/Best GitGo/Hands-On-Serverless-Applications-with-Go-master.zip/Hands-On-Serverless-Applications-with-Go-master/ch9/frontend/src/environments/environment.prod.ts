export const environment = {
  production: true,
  api: 'https://51cxzthvma.execute-api.us-east-1.amazonaws.com/production/movies'
};
