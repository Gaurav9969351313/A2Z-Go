package main

import "fmt"

func main() {
	fmt.Println("Welcome to 'Hands-On Serverless Applications with Go'")
}
