# go-rest
Simple RESTful JSON API in Go
