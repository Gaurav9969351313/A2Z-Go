# go-mysql-rest-api
A guide for creating RESTful API with Golang and MySQL and Gin.

Create a Database called Gotest
then run

  $ ./migrate

to Person table to be created

After download gitter.gz, extract it. You will recieve an executable.
Run that executable and your API server will be up and running

  $ ./gitter

No need of Go installed. That is the beauty.

