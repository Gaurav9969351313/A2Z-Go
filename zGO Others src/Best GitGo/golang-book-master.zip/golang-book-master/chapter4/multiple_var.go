package main

import "fmt"

var (
	a = 5
	b = 10
	c = 15
)

func main() {
	fmt.Println(a, b, c)
}
