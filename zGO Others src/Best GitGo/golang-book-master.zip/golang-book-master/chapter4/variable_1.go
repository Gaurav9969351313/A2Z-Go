package main

import "fmt"

func main() {
	var x string
	x = "Hello World"
	fmt.Println(x)
}
