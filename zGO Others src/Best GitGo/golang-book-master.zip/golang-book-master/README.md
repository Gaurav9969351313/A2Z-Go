Golang-book 
===========

Chapter-by-chapter examples and problems from [An Introduction to Programming in Go](http://www.golang-book.com/) by Caleb Doxsey.



