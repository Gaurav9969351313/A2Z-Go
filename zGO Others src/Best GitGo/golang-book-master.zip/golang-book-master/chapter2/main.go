package main

import "fmt"

// this is a comment

func main() {
	var x string = "Hello World"
	fmt.Println(x)
}
