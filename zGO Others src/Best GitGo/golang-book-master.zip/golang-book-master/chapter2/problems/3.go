// We used the `Println` function defined in the `fmt`
// package. If we wanted to use the `Exit` function from
// the `os` package what would we need to do?

package main

import "os"

func main() {
	Exit()
}
