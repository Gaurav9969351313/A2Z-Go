package main

import "fmt"

func main() {
	fmt.Println("1 + 1 =", 1.0+1.0)
}
