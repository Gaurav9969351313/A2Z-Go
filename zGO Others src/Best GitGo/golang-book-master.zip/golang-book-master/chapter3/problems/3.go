package main

import "fmt"

func main() {
	fmt.Println(uint64(321325 * 424521))
}
