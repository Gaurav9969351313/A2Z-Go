This document has been moved.

https://github.com/ardanlabs/gotraining/tree/master/topics/go