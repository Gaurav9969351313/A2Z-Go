## Ultimate Web

This is material for any Go developer who wishes to learn how to build robust and well tested HTTP based applications in Go. This class provides an intensive, comprehensive and idiomatic view of how to build Web, SOA, and API applications using Go.

[Ultimate Web](../courses/web/README.md)