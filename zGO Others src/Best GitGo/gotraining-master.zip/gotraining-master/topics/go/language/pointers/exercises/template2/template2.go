// All material is licensed under the Apache License Version 2.0, January 2004
// http://www.apache.org/licenses/LICENSE-2.0

// Declare a struct type and create a value of this type. Declare a function
// that can change the value of some field in this struct type. Display the
// value before and after the call to your function.
package main

// Add imports.

// Declare a type named user.

// Create a function that changes the value of one of the user fields.
func funcName( /* add pointer parameter, add value parameter */ ) {

	// Use the pointer to change the value that the
	// pointer points to.
}

func main() {

	// Create a variable of type user and initialize each field.

	// Display the value of the variable.

	// Share the variable with the function you declared above.

	// Display the value of the variable.
}
