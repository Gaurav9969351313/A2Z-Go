package common

// JSON alias type
type JSON = map[string]interface{}
